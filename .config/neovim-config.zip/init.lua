require("kirb.set")
print("hello")
